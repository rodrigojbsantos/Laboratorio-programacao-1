Arquivo zip gerado em: 12/05/2021 20:38:57 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: L5-3 : Primos no intervalo
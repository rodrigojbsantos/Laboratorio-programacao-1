Arquivo zip gerado em: 12/05/2021 15:22:12 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: L5-3 : Primos no intervalo
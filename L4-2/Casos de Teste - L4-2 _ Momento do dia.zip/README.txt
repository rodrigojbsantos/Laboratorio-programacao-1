Arquivo zip gerado em: 02/05/2021 12:19:10 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: L4-2 : Momento do dia 
Arquivo zip gerado em: 26/05/2021 20:31:27 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: L7-2 : Contagem de palavras
Arquivo zip gerado em: 12/05/2021 13:35:17 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: L5-2 : Soma de positivos
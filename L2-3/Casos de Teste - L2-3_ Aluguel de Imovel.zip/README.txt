Arquivo zip gerado em: 23/04/2021 12:42:52 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: L2-3: Aluguel de Imóvel
Arquivo zip gerado em: 15/04/2021 23:48:57 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: L1-2 : Área do retângulo